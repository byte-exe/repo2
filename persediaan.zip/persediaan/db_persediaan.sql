-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2023 at 02:10 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_persediaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `benih`
--

CREATE TABLE `benih` (
  `kd_benih` varchar(128) NOT NULL,
  `nama_benih` varchar(128) DEFAULT NULL,
  `kategori` int(11) DEFAULT NULL,
  `satuan` int(11) DEFAULT NULL,
  `kegunaan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `benih`
--

INSERT INTO `benih` (`kd_benih`, `nama_benih`, `kategori`, `satuan`, `kegunaan`) VALUES
('KB-00151', 'Mangga', 7, 8, 'asd'),
('OB-00150', 'Jeruk ', 9, 8, 'Bibit Tanaman Jeruk');

-- --------------------------------------------------------

--
-- Table structure for table `benihkeluar`
--

CREATE TABLE `benihkeluar` (
  `id_benihkeluar` int(11) NOT NULL,
  `kd_customer` varchar(128) DEFAULT NULL,
  `kd_benih` varchar(128) DEFAULT NULL,
  `tgl_benihkeluar` date DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `nama_petugas` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `benihkeluar`
--

INSERT INTO `benihkeluar` (`id_benihkeluar`, `kd_customer`, `kd_benih`, `tgl_benihkeluar`, `qty`, `nama_petugas`) VALUES
(37, 'PS-00011', 'KB-00151 ', '2023-01-27', 10, 'Tika');

--
-- Triggers `benihkeluar`
--
DELIMITER $$
CREATE TRIGGER `hapusbenih` AFTER DELETE ON `benihkeluar` FOR EACH ROW BEGIN
 UPDATE stok
 SET qty = qty + OLD.qty
 WHERE
 kd_benih = OLD.kd_benih;
 END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `keluarbenih` AFTER INSERT ON `benihkeluar` FOR EACH ROW BEGIN
 UPDATE stok
 SET qty = qty - NEW.qty
 WHERE
 kd_benih = NEW.kd_benih;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `benihmasuk`
--

CREATE TABLE `benihmasuk` (
  `id_benihmasuk` int(11) NOT NULL,
  `kd_benih` varchar(128) DEFAULT NULL,
  `tgl_benihmasuk` date DEFAULT NULL,
  `tgl_expired` date DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `nama_petugas` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `benihmasuk`
--

INSERT INTO `benihmasuk` (`id_benihmasuk`, `kd_benih`, `tgl_benihmasuk`, `tgl_expired`, `qty`, `nama_petugas`) VALUES
(136, 'OB-00150 ', '2023-01-27', '2023-01-27', 1000, 'Pimpinan'),
(137, 'OB-00150 ', '2023-01-27', '2023-01-27', 700, 'Pimpinan'),
(138, 'OB-00150 ', '2023-01-27', '2023-01-27', 200, 'Pimpinan'),
(139, 'KB-00151 ', '2023-01-27', '2023-01-27', 400, 'Pimpinan');

--
-- Triggers `benihmasuk`
--
DELIMITER $$
CREATE TRIGGER `masukbenih` AFTER INSERT ON `benihmasuk` FOR EACH ROW BEGIN
 INSERT INTO stok SET
 kd_benih = NEW.kd_benih, qty=New.qty
 ON DUPLICATE KEY UPDATE qty=qty+New.qty;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `kd_customer` varchar(128) NOT NULL,
  `nama_customer` varchar(128) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `no_transaksi` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`kd_customer`, `nama_customer`, `alamat`, `no_transaksi`) VALUES
('PS-00009', 'BBI Hortikultura', 'Lubuk Minturun', '27/01/2023'),
('PS-00011', 'wadidaws ', 'asdaasd', '123213313asdas');

-- --------------------------------------------------------

--
-- Table structure for table `kadaluarsa`
--

CREATE TABLE `kadaluarsa` (
  `kd_benih` varchar(128) DEFAULT NULL,
  `tgl_keluar` date DEFAULT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kadaluarsa`
--

INSERT INTO `kadaluarsa` (`kd_benih`, `tgl_keluar`, `qty`) VALUES
('KB-00151', '2023-01-27', 200);

--
-- Triggers `kadaluarsa`
--
DELIMITER $$
CREATE TRIGGER `benihkadaluarsa` AFTER INSERT ON `kadaluarsa` FOR EACH ROW BEGIN
 UPDATE stok
 SET qty = qty - NEW.qty
 WHERE
 kd_benih = NEW.kd_benih;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(7, 'Gunung Omeh'),
(8, 'Mantap'),
(9, 'mantap lagi');

-- --------------------------------------------------------

--
-- Table structure for table `satuan`
--

CREATE TABLE `satuan` (
  `id_satuan` int(11) NOT NULL,
  `nama_satuan` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `satuan`
--

INSERT INTO `satuan` (`id_satuan`, `nama_satuan`) VALUES
(8, 'Batang anu'),
(9, 'pasang');

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `kd_benih` varchar(128) NOT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`kd_benih`, `qty`) VALUES
('KB-00151 ', 190),
('OB-00150 ', 1900);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `role_id`, `is_active`) VALUES
(1, 'Tika', 'admin@gmail.com', '$2a$04$GBRZFF1imRRqvfFRqu/wyes8lEAcNfMx.d/BM2prRjz7Fs7WETS0u', 1, 1),
(2, 'Pimpinan', 'pimpinan@gmail.com', '$2y$10$i8Na85Y3X2SOtD66N5AHJujORMwbKzc48t5MkldjWt6B9ir7RBgzq', 2, 1),
(7, 'Tika', 'tika@gmail.com', '$2y$10$eMWNrH/vGxzJFlRmFxumE.0l.qBw/YOw19W4wZ6YfJVIo.C/ktKHW', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 1, 3),
(4, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'Asisten');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `url` varchar(128) DEFAULT NULL,
  `icon` varchar(128) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Dashboard', 'admin', 'fas fa-fw fa-tachometer-alt', 1),
(2, 1, 'Benih', 'obat', 'fas fa-fw fa-tree', 1),
(3, 1, 'Customer', 'pasien', 'fas fa-fw fa-chalkboard-teacher', 1),
(4, 2, 'Dashboard', 'user', 'fas fa-fw fa-tachometer-alt', 1),
(5, 1, 'Config User', 'admin/user', 'fas fa-fw fa-users-cog', 1),
(6, 2, 'Benih Masuk', 'obatmasuk', 'fas fa-fw fa-external-link-alt', 1),
(7, 2, 'Data Benih', 'dataobat', 'fas fa-fw fa-tree', 1),
(8, 1, 'Benih Keluar', 'obatkeluar', 'fas fa-fw fa-outdent', 1),
(9, 1, 'Change Password', 'admin/changepassword', 'fas fa-fw fa-user-edit', 1),
(10, 2, 'Change Password', 'user/changepassword', 'fas fa-fw fa-user-edit', 1),
(11, 1, 'Benih Kadarluasa', 'kadaluarsa', 'fas fa-fw fa-shipping-fast', 1),
(12, 1, 'Laporan Customer', 'admin/lap_pasien', 'fas fa-fw fa-print', 0),
(13, 2, 'Laporan Benih Masuk', 'user/lap_obatmasuk', 'fas fa-fw fa-print', 1),
(14, 1, 'Laporan Benih Keluar', 'admin/lap_obatkeluar', 'fas fa-fw fa-print', 1),
(15, 1, 'Laporan Persediaan', 'admin/lap_persediaan', 'fas fa-fw fa-print', 1),
(16, 1, 'Laporan Stok FIFO', 'admin/lap_stok', 'fas fa-fw fa-print', 1),
(17, 1, 'Laporan Kadaluarsa', 'admin/lap_kadaluarsa', 'fas fa-fw fa-print', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_lap_benih`
-- (See below for the actual view)
--
CREATE TABLE `view_lap_benih` (
`kd_benih` varchar(128)
,`nama_benih` varchar(128)
,`nama_kategori` varchar(128)
,`nama_satuan` varchar(128)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_lap_benihkeluar`
-- (See below for the actual view)
--
CREATE TABLE `view_lap_benihkeluar` (
`nama_customer` varchar(128)
,`nama_benih` varchar(128)
,`tgl_benihkeluar` date
,`qty` int(11)
,`nama_petugas` varchar(128)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_lap_benihmasuk`
-- (See below for the actual view)
--
CREATE TABLE `view_lap_benihmasuk` (
`kd_benih` varchar(128)
,`nama_benih` varchar(128)
,`tgl_benihmasuk` date
,`tgl_expired` date
,`qty` int(11)
,`nama_petugas` varchar(128)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_lap_customer`
-- (See below for the actual view)
--
CREATE TABLE `view_lap_customer` (
`kd_customer` varchar(128)
,`nama_customer` varchar(128)
,`alamat` text
,`no_transaksi` varchar(128)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_lap_persediaan`
-- (See below for the actual view)
--
CREATE TABLE `view_lap_persediaan` (
`kd_benih` varchar(128)
,`nama_benih` varchar(128)
,`nama_satuan` varchar(128)
,`nama_kategori` varchar(128)
,`qty` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `view_lap_benih`
--
DROP TABLE IF EXISTS `view_lap_benih`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_lap_benih`  AS  (select `benih`.`kd_benih` AS `kd_benih`,`benih`.`nama_benih` AS `nama_benih`,`kategori`.`nama_kategori` AS `nama_kategori`,`satuan`.`nama_satuan` AS `nama_satuan` from ((`benih` join `kategori`) join `satuan`) where `benih`.`kategori` = `kategori`.`id_kategori` and `benih`.`satuan` = `satuan`.`id_satuan`) ;

-- --------------------------------------------------------

--
-- Structure for view `view_lap_benihkeluar`
--
DROP TABLE IF EXISTS `view_lap_benihkeluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_lap_benihkeluar`  AS  (select `customer`.`nama_customer` AS `nama_customer`,`benih`.`nama_benih` AS `nama_benih`,`benihkeluar`.`tgl_benihkeluar` AS `tgl_benihkeluar`,`benihkeluar`.`qty` AS `qty`,`benihkeluar`.`nama_petugas` AS `nama_petugas` from ((`benihkeluar` join `customer`) join `benih`) where `benihkeluar`.`kd_customer` = `customer`.`kd_customer` and `benihkeluar`.`kd_benih` = `benih`.`kd_benih`) ;

-- --------------------------------------------------------

--
-- Structure for view `view_lap_benihmasuk`
--
DROP TABLE IF EXISTS `view_lap_benihmasuk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_lap_benihmasuk`  AS  (select `benihmasuk`.`kd_benih` AS `kd_benih`,`benih`.`nama_benih` AS `nama_benih`,`benihmasuk`.`tgl_benihmasuk` AS `tgl_benihmasuk`,`benihmasuk`.`tgl_expired` AS `tgl_expired`,`benihmasuk`.`qty` AS `qty`,`benihmasuk`.`nama_petugas` AS `nama_petugas` from (`benihmasuk` join `benih`) where `benih`.`kd_benih` = `benihmasuk`.`kd_benih`) ;

-- --------------------------------------------------------

--
-- Structure for view `view_lap_customer`
--
DROP TABLE IF EXISTS `view_lap_customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_lap_customer`  AS  (select `customer`.`kd_customer` AS `kd_customer`,`customer`.`nama_customer` AS `nama_customer`,`customer`.`alamat` AS `alamat`,`customer`.`no_transaksi` AS `no_transaksi` from `customer`) ;

-- --------------------------------------------------------

--
-- Structure for view `view_lap_persediaan`
--
DROP TABLE IF EXISTS `view_lap_persediaan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_lap_persediaan`  AS  (select `benih`.`kd_benih` AS `kd_benih`,`benih`.`nama_benih` AS `nama_benih`,`satuan`.`nama_satuan` AS `nama_satuan`,`kategori`.`nama_kategori` AS `nama_kategori`,`stok`.`qty` AS `qty` from (((`benih` join `stok`) join `kategori`) join `satuan`) where `benih`.`kd_benih` = `stok`.`kd_benih` and `benih`.`kategori` = `kategori`.`id_kategori` and `benih`.`satuan` = `satuan`.`id_satuan`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `benih`
--
ALTER TABLE `benih`
  ADD PRIMARY KEY (`kd_benih`);

--
-- Indexes for table `benihkeluar`
--
ALTER TABLE `benihkeluar`
  ADD PRIMARY KEY (`id_benihkeluar`);

--
-- Indexes for table `benihmasuk`
--
ALTER TABLE `benihmasuk`
  ADD PRIMARY KEY (`id_benihmasuk`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`kd_customer`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id_satuan`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`kd_benih`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `benihkeluar`
--
ALTER TABLE `benihkeluar`
  MODIFY `id_benihkeluar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `benihmasuk`
--
ALTER TABLE `benihmasuk`
  MODIFY `id_benihmasuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `satuan`
--
ALTER TABLE `satuan`
  MODIFY `id_satuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
