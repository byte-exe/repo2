<?php 

class Obatkeluar_model extends CI_model
{

	public function all_obatkeluar()
	{
		$hsl = $this->db->query("SELECT benihkeluar.id_benihkeluar, benihkeluar.tgl_benihkeluar, benihkeluar.qty, benihkeluar.nama_petugas, customer.nama_customer, benih.nama_benih
			FROM (benihkeluar LEFT JOIN customer ON benihkeluar.kd_customer=customer.kd_customer)
			LEFT JOIN benih ON benihkeluar.kd_benih=benih.kd_benih ORDER BY benihkeluar.id_benihkeluar DESC");
		return $hsl;
	}

	public function simpan()
	{
		$user = $this->db->get_where('user',['email'=> $this->session->userdata('email')])->row_array();

		$data = [ 
			'kd_customer' 		=> htmlspecialchars($this->input->post('kd_customer', true)),
			'kd_benih'			=> htmlspecialchars($this->input->post('kd_benih', true)),
			'tgl_benihkeluar'	=> htmlspecialchars($this->input->post('tgl_benihkeluar', true)),
			'qty'				=> htmlspecialchars($this->input->post('qty', true)),
			'nama_petugas' => $user['name']
		];
		$this->db->insert('benihkeluar',$data);
	}

	public function hapus()
	{
		$this->db->where('id_benihkeluar',$this->input->post('id_benihkeluar'));
		$this->db->delete('benihkeluar');
	}


}