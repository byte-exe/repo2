<?php 

class Obat_model extends CI_model
{

	public function kode_obat()   
    {
      $this->db->select('RIGHT(benih.kd_benih,5) as kode', FALSE);
      $this->db->order_by('kd_benih','DESC');    
      $this->db->limit(1);    
          $query = $this->db->get('benih');      //cek dulu apakah ada sudah ada kode di tabel.    
          if($query->num_rows() <> 0){      
           //jika kode ternyata sudah ada.      
             $data = $query->row();      
             $kode = intval($data->kode) + 1;    
         }
         else {      
           //jika kode belum ada      
             $kode = 1;    
         }
          $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
          $kodejadi = "KB-".$kodemax;    // hasilnya OB-00001 dst.
          return $kodejadi;  
    }

	public function all_obat()
	{
		$hsl = $this->db->query("SELECT * FROM benih");
		return $hsl;
	}

	public function simpan()
	{
		$data = [ 
					'kd_benih' 		=> htmlspecialchars($this->input->post('kd_benih', true)),
					'nama_benih'		=> htmlspecialchars($this->input->post('nama_benih', true)),
					'kategori'		=> htmlspecialchars($this->input->post('kategori', true)),
					'satuan'		=> htmlspecialchars($this->input->post('satuan', true)),
					'kegunaan'		=> htmlspecialchars($this->input->post('kegunaan', true))
				];
		$this->db->insert('benih',$data);
	}

	public function ubah()
	{
		$data = [ 
					'nama_benih'		=> htmlspecialchars($this->input->post('nama_benih', true)),
					'kategori'		=> htmlspecialchars($this->input->post('kategori', true)),
					'satuan'		=> htmlspecialchars($this->input->post('satuan', true)),
					'kegunaan'		=> htmlspecialchars($this->input->post('kegunaan', true))
				];
		$this->db->where('kd_benih', $this->input->post('kd_benih'));
		$this->db->update('benih',$data);
	}

	public function hapus()
    {
        $this->db->where('kd_benih',$this->input->post('kd_benih'));
        $this->db->delete('benih');
    }

    public function stok()
    {
    	$hsl = $this->db->query("SELECT * FROM stok");
		return $hsl;
    }

	

}