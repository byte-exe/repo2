<?php 

class Kadaluarsa_model extends CI_model
{
	public function kadaluarsa()
	{
		$hsl = $this->db->query("SELECT benih.kd_benih, benih.nama_benih, stok.qty FROM benih LEFT JOIN stok ON benih.kd_benih = stok.kd_benih WHERE stok.qty >0");
		return $hsl;
	}

	public function all()
	{
		$hsl = $this->db->query("SELECT * FROM kadaluarsa");
		return $hsl;
	}

	public function simpan()
	{
		$data = [
			'kd_benih' => $this->input->post('kd_benih'),
			'tgl_keluar' => date('Y-m-d'),
			'qty' => $this->input->post('jumlah_keluar'),
		];
		$this->db->insert('kadaluarsa',$data);
	}
}