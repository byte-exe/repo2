<?php 

class Laporan_model extends CI_model
{
	public function stok()
	{
		$hsl = $this->db->query("SELECT * FROM view_lap_persediaan");
		return $hsl;
	}

	public function persediaan()
	{
		$hsl = $this->db->query("SELECT * FROM view_lap_persediaan");
		return $hsl;
	}

	public function stokfifo()
	{
		$hsl = $this->db->query("
			SELECT
				benih.kd_benih,
				benih.nama_benih,
				satuan.nama_satuan,
				benihmasuk.qty AS qty_benihmasuk,
				SUM(benihkeluar.qty) AS qty_benihkeluar,
				stok.qty AS qty_stok
			FROM
				benih 
					LEFT JOIN satuan ON benih.satuan=satuan.id_satuan
					LEFT JOIN benihmasuk ON benihmasuk.kd_benih = benih.kd_benih
					LEFT JOIN benihkeluar ON benihkeluar.kd_benih = benih.kd_benih
					LEFT JOIN stok ON stok.kd_benih = benih.kd_benih
			WHERE
				benihmasuk.qty > 0  && stok.qty > 0
			GROUP BY benih.kd_benih
			");
		return $hsl;
	}

	public function obat()
	{
		$hsl = $this->db->query("SELECT * FROM view_lap_benih");
		return $hsl;
	}

	public function obatmasuk($tgl1, $tgl2)
	{
		$hsl = $this->db->query("
			SELECT * FROM view_lap_benihmasuk WHERE tgl_benihmasuk BETWEEN '$tgl1' AND '$tgl2' 
			");
		return $hsl;
	}
	
	public function obatkeluar($tgl1, $tgl2)
	{
		$hsl = $this->db->query("
			SELECT * FROM view_lap_benihkeluar WHERE tgl_benihkeluar BETWEEN '$tgl1' AND '$tgl2'
			");
		return $hsl;
	}

	public function pasien()
	{
		$hsl = $this->db->query("SELECT * FROM view_lap_customer");
		return $hsl;
	}

	public function kadaluarsa($tgl1, $tgl2)
	{
		$hsl = $this->db->query("SELECT * FROM kadaluarsa WHERE tgl_keluar BETWEEN '$tgl1' AND '$tgl2'");
		return $hsl;
	}

}