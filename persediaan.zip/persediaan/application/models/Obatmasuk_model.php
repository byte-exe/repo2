<?php 

class Obatmasuk_model extends CI_model
{

	public function all_obatmasuk()
	{
		$hsl = $this->db->query("
			SELECT benihmasuk.id_benihmasuk, benihmasuk.kd_benih, benih.nama_benih, stok.qty from (benihmasuk LEFT JOIN benih ON benihmasuk.kd_benih=benih.kd_benih) LEFT JOIN stok ON benihmasuk.kd_benih=stok.kd_benih WHERE stok.qty > 0 GROUP BY kd_benih
			");
		return $hsl;
	}

	public function all_dataobat()
	{
		$hsl = $this->db->query("
			SELECT benihmasuk.id_benihmasuk, benihmasuk.kd_benih, benih.nama_benih, satuan.nama_satuan, stok.qty from (benihmasuk LEFT JOIN benih ON benihmasuk.kd_benih=benih.kd_benih) LEFT JOIN stok ON benihmasuk.kd_benih=stok.kd_benih LEFT JOIN satuan ON benih.satuan=satuan.id_satuan WHERE stok.qty > 0 GROUP BY kd_benih
			");
		return $hsl;
	}

	public function obatmasuk()
	{
		$hsl = $this->db->query("SELECT * FROM benih, benihmasuk WHERE benih.kd_benih=benihmasuk.kd_benih");
		return $hsl;
	}

	public function simpan()
	{
		$user = $this->db->get_where('user',['email'=> $this->session->userdata('email')])->row_array();

		$data = [ 
			'kd_benih' 		=> htmlspecialchars($this->input->post('kd_benih', true)),
			'tgl_benihmasuk'	=> htmlspecialchars($this->input->post('tgl_benihmasuk', true)),
			'tgl_expired'		=> htmlspecialchars($this->input->post('tgl_expired', true)),
			'qty'		=> htmlspecialchars($this->input->post('qty', true)),
			'nama_petugas' => $user['name']
		];
		$this->db->insert('benihmasuk',$data);
		
	}

	public function hapus()
	{
		$this->db->where('id_benihmasuk',$this->input->post('id_benihmasuk'));
		$this->db->delete('benihmasuk');

		$this->db->where('kd_benih',$this->input->post('kd_benih'));
		$this->db->delete('stok');

		$this->db->where('kd_benih',$this->input->post('kd_benih'));
		$this->db->delete('benihkeluar');
	}


}