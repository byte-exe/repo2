<?php 

class User_model extends CI_model
{
	public function jumlah_obat()
	{
		$hsl = $this->db->query("SELECT COUNT(*) as benih FROM benihmasuk WHERE qty > 0");
		return $hsl->row();
	}

	public function jumlah_pasien()
	{
		$hsl = $this->db->query("SELECT COUNT(*) as customer FROM customer");
		return $hsl->row();
	}

}