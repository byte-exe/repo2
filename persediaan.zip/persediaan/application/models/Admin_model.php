<?php 

class Admin_model extends CI_model
{
	public function getUserById($id)
	{
		return $this->db->get_where('user', ['id' => $id])->row_array();
	}
	
	public function getUser()
	{
		return $this->db->get('user')->result_array();
	}

	public function jumlah_obat()
	{
		$hsl = $this->db->query("SELECT COUNT(*) as benih FROM benihmasuk WHERE qty > 0");
		return $hsl->row();
	}

	public function jumlah_pasien()
	{
		$hsl = $this->db->query("SELECT COUNT(*) as customer FROM customer");
		return $hsl->row();
	}

	public function add()
	{
		$data = [
				'name' => htmlspecialchars($this->input->post('name',true)),
				'email' => htmlspecialchars($this->input->post('email', true)),
				'password' => password_hash(1234, PASSWORD_DEFAULT),
				'role_id' => 2,
				'is_active' => 0
			];
			$this->db->insert('user', $data);
	}

	public function delete($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('user');
	}

	public function aktif($id)
	{
		$data = [
			"is_active" => 1
		];

		$this->db->where('id', $id);
		$this->db->update('user', $data);
	}

	public function nonaktif($id)
	{
		$data = [
			"is_active" => 0
		];

		$this->db->where('id', $id);
		$this->db->update('user', $data);
	}

	public function notifikasi()
	{
		$hsl = $this->db->query("SELECT id_benihmasuk, benihmasuk.kd_benih, stok.qty, tgl_expired, CURRENT_DATE() AS tgl_skrg, DATEDIFF(tgl_expired, CURRENT_DATE()) AS selisih FROM benihmasuk LEFT JOIN stok ON benihmasuk.kd_benih = stok.kd_benih WHERE stok.qty > 0 GROUP BY benihmasuk.kd_benih");
		return $hsl;
	}
}