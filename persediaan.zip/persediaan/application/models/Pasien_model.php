<?php 

class Pasien_model extends CI_model
{

	public function kode_pasien()   
    {
      $this->db->select('RIGHT(customer.kd_customer,5) as kode', FALSE);
      $this->db->order_by('kd_customer','DESC');    
      $this->db->limit(1);    
          $query = $this->db->get('customer');      //cek dulu apakah ada sudah ada kode di tabel.    
          if($query->num_rows() <> 0){      
           //jika kode ternyata sudah ada.      
             $data = $query->row();      
             $kode = intval($data->kode) + 1;    
         }
         else {      
           //jika kode belum ada      
             $kode = 1;    
         }
          $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
          $kodejadi = "PS-".$kodemax;    // hasilnya PS-00001 dst.
          return $kodejadi;  
    }

	public function all_pasien()
	{
		$hsl = $this->db->query("SELECT * FROM customer");
		return $hsl;
	}

  public function pasien_byId($kd_customer)
  {
    $hsl = $this->db->query("SELECT * FROM customer WHERE kd_customer = '$kd_customer'");
    return $hsl;
  }

	public function simpan()
	{
		$data = [ 
					'kd_customer' 	=> htmlspecialchars($this->input->post('kd_customer', true)),
					'nama_customer'	=> htmlspecialchars($this->input->post('nama_customer', true)),
					'alamat'		=> htmlspecialchars($this->input->post('alamat', true)),
					'no_transaksi'		=> htmlspecialchars($this->input->post('no_transaksi', true))
				];
		$this->db->insert('customer',$data);
	}

  public function ubah()
  {
    $data = [
          'nama_customer' => htmlspecialchars($this->input->post('nama_customer', true)),
          'alamat'    => htmlspecialchars($this->input->post('alamat', true)),
          'no_transaksi'    => htmlspecialchars($this->input->post('no_transaksi', true))
        ];
    $this->db->where('kd_customer', $this->input->post('kd_customer'));
    $this->db->update('customer',$data);
  }

  public function hapus()
    {
      $this->db->where('kd_customer',$this->input->post('kd_customer'));
      $this->db->delete('benihkeluar');

      $this->db->where('kd_customer',$this->input->post('kd_customer'));
      $this->db->delete('customer');
    }

}