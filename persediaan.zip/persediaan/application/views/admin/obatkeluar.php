<!-- MAIN -->
<div class="main">
	<!-- MAIN CONTENT -->
	<div class="main-content">
		<div class="container-fluid">

			<div class="row">
				<div class="col-md-4">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Entry Data</h3>
						</div>


						<div class="panel-body">
							<div class="row">
								<div class="col-md-12">
									<div class="card shadow">
										<div class="card-body">

											<form action="obatkeluar" method="post">

												<div class="form-group">
													<label for="inputobat">Kode Customer</label>
													<input type="text" class="form-control disabled" id="kd_customer" name="kd_customer" readonly>
													<?php echo form_error('kd_customer','<small class="text-danger">','</small>');?>
												</div>

												<div class="form-group">
													<label for="inputobat">Kode Benih</label>
													<input type="text" class="form-control" id="kd_benih" name="kd_benih" readonly>
													<?php echo form_error('kd_benih','<small class="text-danger">','</small>');?>
												</div>

												<div class="form-group">
													<label for="inputobat">Tanggal Keluar</label>
													<div class="input-group date">
														<span class="input-group-addon"><i class="far fa-calendar-alt"></i></span>
														<input type="text" name="tgl_benihkeluar" class="form-control pull-right datepicker" id="datepicker" autocomplete="off" required>
													</div>
												</div>

												<div class="form-group">
													<label for="inputobat">Jumlah</label>
													<input type="hidden" class="form-control" id="qty" name="stok">
													<input type="number" class="form-control" name="qty" required>
												</div>

												<button type="submit" class="btn btn-primary">Simpan</button>

											</form>

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-8">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Customer</h3>
							<div class="right">
								<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
								<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
							</div>
						</div>


						<div class="panel-body">
							<div class="row">
								<div class="col-md-12">
									<div class="card shadow">
										<div class="card-body">

											<div class="table-responsive">
										<table class="table table-striped" id="example4" style="font-size:13px;">
											<thead>
												<tr>
													<th>Kode Customer</th>
													<th>Nama</th>
													<th>No. Transaksi</th>
												</tr>
											</thead>
											<tbody>
												<?php foreach($pasien->result_array() as $p): ?>
													<tr>
														<td><?= $p['kd_customer']; ?></td>
														<td><?=	$p['nama_customer']; ?></td>
														<td><?= $p['no_transaksi']; ?></td>
													</tr>
												<?php endforeach; ?>
											</tbody>
										</table>
									</div>

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="panel">
							<div class="panel-heading">
								<h3 class="panel-title">Benih</h3>
								<div class="right">
								<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
								<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
							</div>
							</div>
							<div class="panel-body">
								<div class="row">
									<div class="col-md-12">
										<div class="card shadow">
											<div class="card-body">
												<div class="table-responsive">
													<table class="table table-striped" id="example5" style="font-size:13px;">
														<thead>
															<tr>
																<th style="width:20px;">Kode Benih</th>
																<th style="width:100px;">Nama Benih</th>
																<th style="width:20px;">Stok</th>
															</tr>
														</thead>
														<tbody>
															<?php
															foreach($obatmasuk->result_array() as $om):
																?>
																<tr>
																	<td><?= $om['kd_benih'] ;?></td>
																	<td><?= $om['nama_benih'] ;?></td>
																	<td><?= $om['qty'] ;?></td>
																</tr>
															<?php endforeach; ?>
														</tbody>
													</table>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--END TABEL OBAT-->
						</div>
				</div>
			</div>
			<!--ROW-->

			<!--TABEL OBATKELUAR-->
			<div class="row">
				<div class="col-md-12">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Benih Keluar</h3>
							<div class="right">
								<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
								<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
							</div>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-12">
									<div class="card shadow">
										<div class="card-body">
											<div class="table-responsive">
												<table class="table table-striped" id="example1" style="font-size:13px;">
													<thead>
														<tr>
															<th>ID</th>
															<th>Customer</th>
															<th>Benih</th>
															<th>Petugas</th>
															<th>Tanggal Keluar</th>
															<th>Jumlah</th>
															<th style="text-align:center; width: 10px;">Delete</th>
														</tr>
													</thead>
													<tbody>
														<?php
														$no=0;
														foreach($obatkeluar->result_array() as $ok): 
														$no++;
														?>
														<tr>
															<td><?= $no; ?></td>
															<td><?= $ok['nama_customer']; ?></td>
															<td><?= $ok['nama_benih']; ?></td>
															<td><?= $ok['nama_petugas']; ?></td>
															<td><?= $ok['tgl_benihkeluar']; ?></td>
															<td><?= $ok['qty']; ?></td>
															<td style="text-align:center;">
																<a class="btn" data-toggle="modal" data-target="#ModalHapus<?= $ok['id_benihkeluar'];?>"><span class="fa fa-trash"></span></a>
															</td>
														</tr>
														<?php endforeach; ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--TABEL OBATKELUAR-->


		</div> 
	</div>
</div>
<!-- END MAIN CONTENT -->

<!--HAPUS OBAT KELUAR-->
<?php foreach($obatkeluar->result_array() as $ok): ?>
	<div class="modal fade" id="ModalHapus<?= $ok['id_benihkeluar'];?>" tabindex="-1" role="dialog" aria-labelledby="ModalHapusLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">

				<div class="panel">
					<div class="panel-heading">
						<div class="modal-header">
							<h3 class="modal-title" id="ModalHapusLabel">Hapus Benih Keluar</h3>
						</div>
					</div>

					<div class="panel-body">
						<div class="row">
							<div class="col-md-12">
								<form class="form-horizontal" action="<?php echo base_url('obatkeluar/hapus'); ?>" method="post" enctype="multipart/form-data">
									<div class="modal-body">
										<input type="hidden" name="id_benihkeluar" value="<?= $ok['id_benihkeluar'];?>"/>

										<p>Apakah Anda yakin mau menghapus Benih keluar <b><?= $ok['nama_benih'];?></b> ?</p>

									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
										<button type="submit" class="btn btn-primary">Hapus</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php endforeach; ?>
<!--END OBAT KELUAR-->